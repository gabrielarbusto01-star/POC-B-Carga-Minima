import sys

EXPECTED = 42

def calculate(value: int) -> int:
    return EXPECTED

if __name__ == "__main__":
    value = int(sys.argv[1]) if len(sys.argv) > 1 else EXPECTED
    print(calculate(value))
