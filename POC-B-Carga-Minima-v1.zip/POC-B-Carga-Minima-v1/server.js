const express = require("express");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const app = express();
const PORT = Number(process.env.APP_PORT || 3000);
const APP_NAME = process.env.APP_NAME || "POC-B";
const EXPECTED_RESULT = Number(process.env.EXPECTED_RESULT || 42);

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (req, res) => {
  try {
    const output = execFileSync("python3", ["scripts/calc.py", String(EXPECTED_RESULT)], {
      encoding: "utf8"
    }).trim();

    res.json({
      ok: Number(output) === EXPECTED_RESULT,
      app: APP_NAME,
      result: Number(output),
      expected: EXPECTED_RESULT
    });
  } catch (error) {
    console.error("Python execution failed:", error.message);
    res.status(500).json({ ok: false, error: "python_execution_failed" });
  }
});

app.listen(PORT, () => {
  console.log(`${APP_NAME} listening on port ${PORT}`);
});
