# POC-B — Carga de Trabalho Mínima

Objetivo: validar uma carga pequena e reproduzível de desenvolvimento em um ambiente remoto.

## Componentes
- Frontend: HTML/CSS/JavaScript sem framework.
- Backend: Node.js + Express.
- Utilitário: Python.
- Testes: Node.js built-in test runner + pytest.
- Dependência Node: Express.
- Dependência Python: pytest.
- Configuração: `.env.example`.
- Git: status, diff, commit e push.

## Execução

```bash
npm install
python3 -m pip install -r requirements.txt
cp .env.example .env
npm test
npm start
```

Abra a URL/porta informada pelo ambiente.

## Teste funcional
A página chama `GET /api/status`. O backend executa `scripts/calc.py` e retorna o resultado.

## Debug proposital
Edite `scripts/calc.py` e altere temporariamente `return EXPECTED` para `return EXPECTED + 1`.
Rode:
```bash
npm test
```
O teste deve falhar. Depois corrija e rode novamente. O teste deve passar.

## Git
Depois dos testes:
```bash
git status
git diff
git add .
git commit -m "POC-B: carga mínima executada"
git push
```

Não coloque segredos reais no `.env`.
