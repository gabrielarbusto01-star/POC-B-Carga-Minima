const test = require("node:test");
const assert = require("node:assert/strict");
const { execFileSync } = require("node:child_process");
const fs = require("node:fs");

test("Python utility returns the expected deterministic result", () => {
  const output = execFileSync("python3", ["scripts/calc.py", "7"], { encoding: "utf8" }).trim();
  assert.equal(Number(output), 42);
});

test("project contains required environment template", () => {
  assert.equal(fs.existsSync(".env.example"), true);
});
