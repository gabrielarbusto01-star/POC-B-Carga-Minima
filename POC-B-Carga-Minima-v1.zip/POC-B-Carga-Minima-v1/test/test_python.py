from scripts.calc import calculate

def test_calculate():
    assert calculate(7) == 42
